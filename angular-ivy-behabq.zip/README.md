# Murex Coding Assignment

## Assignment

The goal of this assignment is to showcase your ability to develop features.
Due to the time constraints you will have to prioritize what you work on, and have to balance cleanliness with just getting it done.

You can easily spend a week on it. Please don't ! Do as much as you can in about two hours and share the result.

The most important part of the interview will come after this one, when we talk about the decision you have made, etc...

## The Application

Build an application to list / add / edit / filter tickets by following the provided design (here : https://www.figma.com/file/fXs4zcbbPr3MEbnlxPtnOL/Code-Assignment?node-id=14%3A427)


- The application will contain two pages:
  - On the first one, list the tickets add a section to filter them, and a button to create one.
  - On the second page, display the creation/edition of a ticket. Please use the Angular Router to manage transitions between these two pages.
- Apply the css (without framework) to match the given design.
- Write a couple of tests (to run the unit tests copy the content of `main.spec.ts` to `main.ts`, this will run the tests in the stackblitz console)



## Submit your assessment.

Fork the project save your modifications on this forked project and email us (mxhr@murex.com). Give us the link of your forked project. We will continue to work on it during the interview. Please also indicate how long you spent on the submission.
