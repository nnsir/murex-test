import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { Ticket, Tickets } from '../shared/ticket';

@Injectable({
  providedIn: 'root',
})
export class TicketService {
  constructor(private readonly http: HttpClient) {}

  public getTickets(): Observable<Tickets> {
    return this.http.get<Tickets>(`assets/tickets.json`);
  }

  public addTicket(ticket: Ticket) {
    //simulate a service
    //return this.http.post<Response>('api/ticket',ticket,header);
  }
}
