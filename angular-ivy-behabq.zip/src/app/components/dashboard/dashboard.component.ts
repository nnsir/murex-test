import { Component } from '@angular/core';
import { Observable } from 'rxjs';
import { Ticket, Tickets } from '../../shared/ticket';
import { map } from 'rxjs/operators';
import { AppService } from '../../app.service';
import { Router } from '@angular/router';
import { TicketService } from '../../services/ticket-service';
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss'],
})
export class DashboardComponent {
  public title = 'coding-assignment';
  public tickets$: Observable<Ticket[]>;
  constructor(service: TicketService, private router: Router) {
    this.tickets$ = service
      .getTickets()
      .pipe(map((tickets: Tickets) => tickets.tickets));
  }

  createTicket() {
    this.router.navigate(['edit-ticket']);
  }
  deleteTicket() {}
}
