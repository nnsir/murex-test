import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { Category, Status, Ticket, Tickets } from '../../shared/ticket';
import { map } from 'rxjs/operators';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { TicketService } from '../../services/ticket-service';
@Component({
  selector: 'app-edit-ticket',
  templateUrl: './edit-ticket.component.html',
  styleUrls: ['./edit-ticket.component.scss'],
})
export class EditTicketComponent implements OnInit {
  public title = 'editTicket';
  public tickets$: Observable<Ticket[]>;
  public categories = Object.keys(Category);
  public status = Object.keys(Status);
  public ticketForm: FormGroup;

  constructor(
    private ticketService: TicketService,
    private formBuilder: FormBuilder
  ) {}

  public ngOnInit(): void {
    this.initFormBuilder();
  }

  private initFormBuilder() {
    this.ticketForm = this.formBuilder.group({
      title: new FormControl(''),
      description: new FormControl(''),
      category: new FormControl(''),
      status: new FormControl(''),
      user: new FormControl(''),
      internal: new FormControl(''),
    });
  }

  public handleConfirm() {
    //be sure if it is a valid ticket
    if (this.ticketForm.valid) {
      const newTicket: Ticket = {
        ...this.ticketForm.value,
        id: null,
      };
      this.ticketService.addTicket(newTicket);
    } else {
      alert('invalid form !');
    }
    console.log(JSON.stringify(this.ticketForm.value));
  }
}
