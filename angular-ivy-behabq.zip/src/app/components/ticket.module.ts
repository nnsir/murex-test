import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { DashboardComponent } from '../components/dashboard/dashboard.component';
import { EditTicketComponent } from '../components/edit-ticket/edit-ticket.component';
import { TicketComponent } from './ticket/ticket.component';

@NgModule({
  declarations: [DashboardComponent, EditTicketComponent, TicketComponent],
  imports: [CommonModule, FormsModule, ReactiveFormsModule],
})
export class TicketModule {}
